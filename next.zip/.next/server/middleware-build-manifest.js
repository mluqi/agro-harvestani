globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/e60ef129113f6e24.js",
      "static/chunks/b7976f5ad813f453.js",
      "static/chunks/turbopack-7f888032fdc824a7.js"
    ],
    "/_error": [
      "static/chunks/17722e3ac4e00587.js",
      "static/chunks/b7976f5ad813f453.js",
      "static/chunks/turbopack-3e869536294e875e.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/690181e5a4f6c943.js",
    "static/chunks/522518d740397639.js",
    "static/chunks/ef7f5d20fc656153.js",
    "static/chunks/569cf8acca53835e.js",
    "static/chunks/2008ffcf9e5b170c.js",
    "static/chunks/turbopack-6e114ea21cedd410.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];