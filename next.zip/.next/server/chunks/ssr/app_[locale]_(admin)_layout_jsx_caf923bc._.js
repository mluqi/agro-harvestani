module.exports=[23962,a=>{"use strict";a.s(["default",()=>c]);var b=a.i(7997);function c({children:a}){return(0,b.jsx)(b.Fragment,{children:a})}}];

//# sourceMappingURL=app_%5Blocale%5D_%28admin%29_layout_jsx_caf923bc._.js.map