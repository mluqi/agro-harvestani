__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/b7976f5ad813f453.js",
  "static/chunks/turbopack-7f888032fdc824a7.js"
])
